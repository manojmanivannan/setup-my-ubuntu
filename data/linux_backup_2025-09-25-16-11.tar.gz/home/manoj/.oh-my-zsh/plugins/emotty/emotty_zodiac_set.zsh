#!/usr/bin/env zsh
# vim:ft=zsh ts=2 sw=2 sts=2

_emotty_sets[zodiac]="
  aries
  taurus
  gemini
  cancer
  leo
  virgo
  libra
  scorpius
  sagittarius
  capricorn
  aquarius
  pisces
  rat
  ox
  tiger
  rabbit
  dragon
  snake
  horse
  goat
  monkey
  rooster
  dog
  pig
  "
