if [ $commands[kompose] ]; then
  source <(kompose completion zsh)
fi
